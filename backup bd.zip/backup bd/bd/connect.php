<?php
   
        $con = new mysqli("localhost", "root", "", "amarbd") or die(mysql_error());
        
?>
