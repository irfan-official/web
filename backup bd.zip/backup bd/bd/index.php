<?php
      include('connect.php');
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Form Login and Register</title>
        <link rel="stylesheet" herf="style.css">

</head>
<body>
    <h1>WELCOME USER</h1>
    <a herf="login.php">Logout</a>
</body>
</html>