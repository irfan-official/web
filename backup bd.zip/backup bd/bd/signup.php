
<?php
session_start();

include("connect.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $nationality = $_POST['nationality'];

    // Use a regular expression to validate the email format
    if (!empty($email) && !empty($password) && preg_match('/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/', $email)) {
        $query = "INSERT INTO signup (firstname, lastname, gender, email, password, nationality) VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $con->prepare($query);
        $stmt->bind_param("ssssss", $firstname, $lastname, $gender, $email, $password, $nationality);

        if ($stmt->execute()) {
            echo "<script type='text/javascript'> alert('Successfully Registered')</script>";
        } else {
            echo "<script type='text/javascript'> alert('Failed to Register')</script>";
        }

        $stmt->close();
    } else {
        echo "<script type='text/javascript'> alert('Please enter a valid email address')</script>";
    }
}


?>

<style>
  body {
    margin: 0;
    padding: 0;
    background-image: url('nice_2.png');
    background-size: cover;
    font-family: Arial, sans-serif;
    color: white; /* Set text color to white */
  }
  
  .signup-container {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  
  .signup-box {
    width: 300px;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.40);
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.3);
  }
  
  input[type="text"], input[type="password"] {
    width: 100%;
    padding: 4px;
    margin: 4px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: rgba(255, 255, 255, 0.1); /* Further reduced brightness */
    color: white; /* Set text color to white */
  }
  
  input[type="text"]::placeholder,
  input[type="password"]::placeholder {
    color: rgba(255, 255, 255, 0.4); /* Further reduced brightness */
  }
  
  .radio-label {
    margin-right: 10px;
  }
  
  .gender-options {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px; /* Added double line spacing */
  }
  
  .button-container {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
  }
  
  .button {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  
  .button.register {
    text-decoration: none;
    background-color: #3498db;
    color: white;
  }

  input[type="submit"]
  {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    background-color:#ff7200;
    color: white;
  }
  .button.back {
    text-decoration: none;
    background-color: #95a5a6;
    color: white;
  }
  
</style>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Signup Page</title>

</head>
<body>
<div class="signup-container">   
  <div class="signup-box">
    <form method="POST">
    <h2>Signup</h2>
    <input type="text" name="firstname" required placeholder="First Name">
    <input type="text" name="lastname" required placeholder="Last Name">
    <p>Gender</p>
    <div class="gender-options">
    
                <div>
                  <label for="male" class="radio-label"
                    ><input
                      type="radio"
                      name="gender"
                      value="MALE"
                      id="male"
                    />Male</label
                  >
                  <label for="female" class="radio-label"
                    ><input
                      type="radio"
                      name="gender"
                      value="FEMALE"
                      id="female"
                    />Female</label
                  >
                  <label for="others" class="radio-label"
                    ><input
                      type="radio"
                      name="gender"
                      value="OTHERS"
                      id="others"
                    />Others</label
                  >
                </div>
    </div>
    <input type="text" name="email" required placeholder="Email ID">
    <input type="password" name="password" required placeholder="Password">
    <p>Are you a Bangladeshi?</p>
    <label class="radio-label"><input type="radio" name="nationality" value="YES"> Yes</label>
    <label class="radio-label"><input type="radio" name="nationality" value="NO"> No</label>
    <div class="button-container">
    <input type= "submit" name="" value="Submit">
      <a href="index.html" class="button back">Back</a>
    </div>
</form>
  </div>
</div>
</body>
</html>
