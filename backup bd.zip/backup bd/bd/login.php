
<?php
session_start();

include("connect.php");

if($_SERVER['REQUEST_METHOD'] == "POST")
{
    $email = $_POST['email'];
  $password = $_POST['password'];

  if (!empty($email) && !empty($password) && !is_numeric($email))
  {
    $query = "SELECT * FROM signup WHERE email = '$email' limit 1";
    $result = mysqli_query($con, $query);

    if($result)
    {
        if($result && mysqli_num_rows($result) > 0)
        {
            $user_data = mysqli_fetch_assoc($result);

            if($user_data['password'] == $password)
            {
                header("location: sub/str.html");
                die;
                 
            }
        }
    }  
      echo "<script type='text/javascript'> alert('worng username or password')</script>";
  }

  else
  {
    echo "<script type='text/javascript'> alert('Successfully Registered')</script>";
  }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Page</title>
<style>
  body {
    margin: 0;
    padding: 0;
    background-image: url('nice.png');
    background-size: cover;
    font-family: Arial, sans-serif;
  }
  
  .login-container {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  
  .login-box {
    width: 300px;
    padding: 20px;
    background-color: rgb(255 255 255 / 0%);
    border-radius: 12px;
    box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.9);
  }
  
  input[type="text"], input[type="password"] {
    width: 100%;
    padding: 5px;
    margin: 5px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: rgba(255, 255, 255, 0.18); /* Slightly reduced brightness */
    color: white; /* Set text color to white */
  }
  
  input[type="text"]::placeholder,
  input[type="password"]::placeholder {
    color: rgba(255, 255, 255, 0.5); /* Further reduced brightness */
  }
  
  .button-container {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
  }
  
  .button {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    color: white; /* Set text color to white */
  }
  
  .button.login {
    background-color: #3498db;
  }
  
  .button.back {
    text-decoration: none;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    color: white;
    background-color: #95a5a6; 
    
  }

  input[type="submit"]
  {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    background-color:#ff7200;
    color: white;
  }

</style>
</head>
<body>
<div class="login-container">
  <div class="login-box">
    <h2 style="color: white;">Login</h2>
  <form method="POST">
    <input type="text" name="email" required placeholder="Email ID">
    <input type="password" name="password" required placeholder="Password">

    <div class="button-container">
    <input type= "submit" name="" value="Login">
      <a href="index.html" class="button back">Back</a>
  </form>
    </div>
  </div>
</div>
</body>
</html>
